// 狗头搜索 —— 样式负责换头，脚本只补一句提示
const setTitle = () => {
  const btn = document.querySelector('#home-search .hs-submit');
  if (btn) btn.title = '汪！搜索';
};

setTitle();

// 首页重绘后补一次（切换插件、改设置都可能重建首页）
const observer = new MutationObserver(setTitle);
const home = document.getElementById('home');
if (home) observer.observe(home, { childList: true, subtree: true });

Cho.cleanup(() => observer.disconnect());
Cho.log('狗头搜索已启用');
